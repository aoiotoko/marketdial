module.exports = {
  env: {
    mocha: true
  },
  rules: {
    'no-unused-expressions': 0
  }
}
